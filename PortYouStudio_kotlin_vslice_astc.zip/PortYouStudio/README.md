# PortYou Studio

Offline Android app (Android 7+ / arm64, target < 25 MB) that ports **Funkin Mod Maker (.FNMM / zip / 7z / rar)** and **V-Slice** mods to
**Psych Engine 1.0.4 (mobile)**. One mod at a time, up to 2 GB.

## Status
| Piece | State |
|---|---|
| UI: main screen, settings (languages, sounds, description, Akram bubble), loading / success / fail screens, music, click sounds, intro video | done (needs on-device pixel tuning) |
| Funky Maker -> Psych (chart, sustains, character atlas + json, icons, stage, all 15 FNMM actions via `fnmm_runtime.lua`, week, pack.json) | done, reference run verified (`tools/fnmm_to_psych.py`) |
| Save-location memory (SAF tree) | done |
| V-Slice converter, Haxe -> Lua, sprite-map -> sheet, vocal merging | **done in Python (reference) AND ported to Kotlin** (`Atlas.kt`, `Hx2Lua.kt`, `VSliceConverter.kt`, `AudioMerge.kt`); the Kotlin code has not been compiled/run yet - first CI build + phone test pending. ASTC texture decoding is now written (`Astc.kt`, checked against a Python reference + own-encoder round trip, not against real ASTC files or on a phone) |

## Build
Push to GitHub: the **Build APK** workflow produces `PortYouStudio-apk` and fails if the APK is over 25 MB.
Local: `gradle :app:assembleRelease` (JDK 17, Android SDK 34).

## Tools
- `tools/prepare_assets.py` — regenerates `app/src/main/assets/ui` from the original art.
- `tools/fnmm_to_psych.py` + `tools/fnmm_runtime.lua` — reference converter (the Kotlin port mirrors it). Run:
  `python3 tools/fnmm_to_psych.py mod.FNMM out/`

## Credits
App by axelzerox023 — [YouTube](https://youtube.com/@axelzerox023) · [Instagram](https://www.instagram.com/axelzerox023)
Friend: [Akram](https://youtube.com/@akrammakak-official)
