package com.portyou.studio.convert

import com.github.junrar.Archive as RarArchive
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

class UnsupportedModException(msg: String) : Exception(msg)

object Archive {
    /** Extracts zip / 7z / rar / FNMM (zip) into dest. Guards against path traversal ("zip slip"). */
    fun extract(src: File, dest: File) {
        dest.mkdirs()
        val magic = ByteArray(6)
        src.inputStream().use { it.read(magic) }
        when {
            magic[0] == 'P'.code.toByte() && magic[1] == 'K'.code.toByte() -> zip(src, dest)
            magic[0] == '7'.code.toByte() && magic[1] == 'z'.code.toByte() -> sevenZ(src, dest)
            magic[0] == 'R'.code.toByte() && magic[1] == 'a'.code.toByte() && magic[2] == 'r'.code.toByte() -> rar(src, dest)
            else -> throw UnsupportedModException("Not an archive")
        }
    }
    private fun safe(dest: File, name: String): File {
        val f = File(dest, name.replace('\\', '/'))
        if (!f.canonicalPath.startsWith(dest.canonicalPath + File.separator)) throw UnsupportedModException("Unsafe path: $name")
        return f
    }
    private fun zip(src: File, dest: File) = ZipFile(src).use { z ->
        for (e in z.entries()) {
            val f = safe(dest, e.name)
            if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); z.getInputStream(e).use { i -> FileOutputStream(f).use { o -> i.copyTo(o) } } }
        }
    }
    private fun sevenZ(src: File, dest: File) = SevenZFile(src).use { z ->
        while (true) {
            val e = z.nextEntry ?: break
            val f = safe(dest, e.name)
            if (e.isDirectory) { f.mkdirs(); continue }
            f.parentFile?.mkdirs()
            FileOutputStream(f).use { o -> val buf = ByteArray(64 * 1024); while (true) { val n = z.read(buf); if (n < 0) break; o.write(buf, 0, n) } }
        }
    }
    private fun rar(src: File, dest: File) = RarArchive(src).use { a ->
        while (true) {
            val h = a.nextFileHeader() ?: break
            val f = safe(dest, h.fileName)
            if (h.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); FileOutputStream(f).use { o -> a.extractFile(h, o) } }
        }
    }
}
