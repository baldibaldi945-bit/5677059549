package com.portyou.studio.convert

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater

/**
 * ASTC (LDR, 2D) -> PNG, pure Kotlin (Android's BitmapFactory cannot read ASTC files).
 * Reads: raw ".astc" files (16-byte header) and KTX1 files whose glInternalFormat is ASTC.
 * Detection is by the file's first bytes, not by extension, so an ASTC payload named ".png" is converted too.
 * Output is streamed row by row, so even 4096x4096 sheets need only a few MB of RAM.
 * HDR endpoints / 3D blocks are not supported (written as magenta / skipped).
 */
object Astc {
    private val QL = intArrayOf(2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 160, 192, 256)
    private val QKIND = intArrayOf(0, 1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0, 2, 1, 0)   // 0 bits only, 1 trit, 2 quint
    private val QBITS = intArrayOf(1, 0, 2, 0, 1, 3, 1, 2, 4, 2, 3, 5, 3, 4, 6, 4, 5, 7, 5, 6, 8)
    private val TSZ = intArrayOf(2, 2, 1, 2, 1); private val TSH = intArrayOf(0, 2, 4, 5, 7)
    private val QSZ = intArrayOf(3, 2, 2); private val QSH = intArrayOf(0, 3, 5)
    private const val ERR = -65281   // 0xFFFF00FF = opaque magenta (error colour)

    private fun bit(m: Int, i: Int) = (m shr i) and 1

    private fun iseBits(n: Int, qi: Int): Int {
        val b = n * QBITS[qi]
        return when (QKIND[qi]) { 1 -> b + (8 * n + 4) / 5; 2 -> b + (7 * n + 2) / 3; else -> b }
    }

    // ---- trit / quint tables (verified: 243 / 125 distinct combinations) ----
    private val TRIT: Array<IntArray> = Array(256) { tritDec(it) }
    private val QUINT: Array<IntArray> = Array(128) { quintDec(it) }

    private fun tritDec(t: Int): IntArray {
        val c: Int; val t4: Int; val t3: Int
        if (((t shr 2) and 7) == 7) { c = (((t shr 5) and 7) shl 2) or (t and 3); t4 = 2; t3 = 2 }
        else {
            c = t and 31
            if (((t shr 5) and 3) == 3) { t4 = 2; t3 = bit(t, 7) } else { t4 = bit(t, 7); t3 = (t shr 5) and 3 }
        }
        val t2: Int; val t1: Int; val t0: Int
        if ((c and 3) == 3) { t2 = 2; t1 = bit(c, 4); val c3 = bit(c, 3); t0 = (c3 shl 1) or (bit(c, 2) and (1 - c3)) }
        else if (((c shr 2) and 3) == 3) { t2 = 2; t1 = 2; t0 = c and 3 }
        else { t2 = bit(c, 4); t1 = (c shr 2) and 3; t0 = c and 3 }
        return intArrayOf(t0, t1, t2, t3, t4)
    }

    private fun quintDec(q: Int): IntArray {
        fun g(h: Int, l: Int) = (q shr l) and ((1 shl (h - l + 1)) - 1)
        val q0: Int; val q1: Int; val q2: Int
        if (g(2, 1) == 3 && g(6, 5) == 0) {
            q0 = 4; q1 = 4
            q2 = (g(0, 0) shl 2) or ((g(4, 4) and (1 - g(0, 0))) shl 1) or (g(3, 3) and (1 - g(0, 0)))
        } else {
            val c: Int
            if (g(2, 1) == 3) { q2 = 4; c = (g(4, 3) shl 3) or (((g(6, 5)).inv() and 3) shl 1) or g(0, 0) }
            else { q2 = g(6, 5); c = g(4, 0) }
            if ((c and 7) == 5) { q1 = 4; q0 = (c shr 3) and 3 } else { q1 = (c shr 3) and 3; q0 = c and 7 }
        }
        return intArrayOf(q0, q1, q2)
    }

    // ---- bit reader over a 128-bit block held as two longs ----
    private class Bits(val lo: Long, val hi: Long, var pos: Int) {
        fun get(n: Int): Int {
            if (n <= 0) return 0
            val mask = (1L shl n) - 1
            val r = if (pos + n <= 64) (lo ushr pos) and mask
            else if (pos >= 64) (hi ushr (pos - 64)) and mask
            else ((lo ushr pos) or (hi shl (64 - pos))) and mask
            pos += n
            return r.toInt()
        }
    }

    private fun iseDecode(b: Bits, n: Int, qi: Int, dOut: IntArray, mOut: IntArray) {
        val nb = QBITS[qi]
        when (QKIND[qi]) {
            0 -> for (i in 0 until n) { dOut[i] = 0; mOut[i] = b.get(nb) }
            1 -> {
                var i = 0
                val ms = IntArray(5)
                while (i < n) {
                    val cnt = minOf(5, n - i); var t = 0
                    for (j in 0 until cnt) { ms[j] = b.get(nb); t = t or (b.get(TSZ[j]) shl TSH[j]) }
                    val ds = TRIT[t]
                    for (j in 0 until cnt) { dOut[i + j] = ds[j]; mOut[i + j] = ms[j] }
                    i += cnt
                }
            }
            else -> {
                var i = 0
                val ms = IntArray(3)
                while (i < n) {
                    val cnt = minOf(3, n - i); var t = 0
                    for (j in 0 until cnt) { ms[j] = b.get(nb); t = t or (b.get(QSZ[j]) shl QSH[j]) }
                    val ds = QUINT[t]
                    for (j in 0 until cnt) { dOut[i + j] = ds[j]; mOut[i + j] = ms[j] }
                    i += cnt
                }
            }
        }
    }

    // ---- unquantisation ----
    private fun rep(m: Int, nb: Int, tot: Int): Int {
        var r = 0; var sh = tot - nb
        while (sh > -nb) { r = r or (if (sh >= 0) (m shl sh) else (m shr (-sh))); sh -= nb }
        return r
    }

    private fun unqColor(qi: Int, d: Int, m: Int): Int {
        val l = QL[qi]
        if (QKIND[qi] == 0) return rep(m, QBITS[qi], 8)
        val c: Int; val b: Int
        when (l) {
            6 -> { c = 204; b = 0 }
            12 -> { c = 93; b = (bit(m, 1) shl 8) or (bit(m, 1) shl 4) or (bit(m, 1) shl 2) or (bit(m, 1) shl 1) }
            24 -> { c = 44; b = (bit(m, 2) shl 8) or (bit(m, 1) shl 7) or (bit(m, 2) shl 3) or (bit(m, 1) shl 2) or (bit(m, 2) shl 1) or bit(m, 1) }
            48 -> { c = 22; b = (bit(m, 3) shl 8) or (bit(m, 2) shl 7) or (bit(m, 1) shl 6) or (bit(m, 3) shl 2) or (bit(m, 2) shl 1) or bit(m, 1) }
            96 -> { c = 11; b = (bit(m, 4) shl 8) or (bit(m, 3) shl 7) or (bit(m, 2) shl 6) or (bit(m, 1) shl 5) or (bit(m, 4) shl 1) or bit(m, 3) }
            192 -> { c = 5; b = (bit(m, 5) shl 8) or (bit(m, 4) shl 7) or (bit(m, 3) shl 6) or (bit(m, 2) shl 5) or (bit(m, 1) shl 4) or bit(m, 5) }
            10 -> { c = 113; b = 0 }
            20 -> { c = 54; b = (bit(m, 1) shl 8) or (bit(m, 1) shl 3) or (bit(m, 1) shl 2) }
            40 -> { c = 26; b = (bit(m, 2) shl 8) or (bit(m, 1) shl 7) or (bit(m, 2) shl 2) or (bit(m, 1) shl 1) }
            80 -> { c = 13; b = (bit(m, 3) shl 8) or (bit(m, 2) shl 7) or (bit(m, 1) shl 6) or (bit(m, 3) shl 1) or bit(m, 2) }
            else -> { c = 6; b = (bit(m, 4) shl 8) or (bit(m, 3) shl 7) or (bit(m, 2) shl 6) or (bit(m, 1) shl 5) or bit(m, 4) }   // 160
        }
        val a = if ((m and 1) == 1) 0x1FF else 0
        val t = (d * c + b) xor a
        return (a and 0x80) or ((t shr 2) and 0x7F)
    }

    private fun unqWeight(qi: Int, d: Int, m: Int): Int {
        val l = QL[qi]
        var w: Int
        if (QKIND[qi] == 0) {
            w = when (QBITS[qi]) { 1 -> m * 63; 2 -> m * 21; 3 -> m * 9; 4 -> (m shl 2) or (m shr 2); else -> (m shl 1) or (m shr 4) }
        } else if (l == 3) w = intArrayOf(0, 32, 63)[d]
        else if (l == 5) w = intArrayOf(0, 16, 32, 47, 63)[d]
        else {
            val c: Int; val b: Int
            when (l) {
                6 -> { c = 50; b = 0 }
                12 -> { c = 23; b = (bit(m, 1) shl 6) or (bit(m, 1) shl 2) or bit(m, 1) }
                24 -> { c = 11; b = (bit(m, 2) shl 6) or (bit(m, 1) shl 5) or (bit(m, 2) shl 1) or bit(m, 1) }
                10 -> { c = 28; b = 0 }
                else -> { c = 13; b = (bit(m, 1) shl 6) or (bit(m, 1) shl 1) }   // 20
            }
            val a = if ((m and 1) == 1) 0x7F else 0
            val t = (d * c + b) xor a
            w = (a and 0x20) or ((t shr 2) and 0x1F)
        }
        return if (w > 32) w + 1 else w
    }

    // ---- partitions ----
    private fun hash52(p0: Int): Int {
        var p = p0
        p = p xor (p ushr 15); p -= (p shl 17); p += (p shl 7); p += (p shl 4)
        p = p xor (p ushr 5); p += (p shl 16); p = p xor (p ushr 7); p = p xor (p ushr 3)
        p = p xor (p shl 6); p = p xor (p ushr 17)
        return p
    }

    private fun partition(seed0: Int, x0: Int, y0: Int, pc: Int, small: Boolean): Int {
        var x = x0; var y = y0
        if (small) { x = x shl 1; y = y shl 1 }
        val seed = seed0 + (pc - 1) * 1024
        val r = hash52(seed)
        val s = IntArray(13)
        s[1] = r and 15; s[2] = (r ushr 4) and 15; s[3] = (r ushr 8) and 15; s[4] = (r ushr 12) and 15
        s[5] = (r ushr 16) and 15; s[6] = (r ushr 20) and 15; s[7] = (r ushr 24) and 15; s[8] = (r ushr 28) and 15
        s[9] = (r ushr 18) and 15; s[10] = (r ushr 22) and 15; s[11] = (r ushr 26) and 15
        s[12] = ((r ushr 30) or (r shl 2)) and 15
        for (i in 1..12) s[i] = s[i] * s[i]
        val sh1: Int; val sh2: Int
        if ((seed and 1) != 0) { sh1 = if ((seed and 2) != 0) 4 else 5; sh2 = if (pc == 3) 6 else 5 }
        else { sh1 = if (pc == 3) 6 else 5; sh2 = if ((seed and 2) != 0) 4 else 5 }
        val sh3 = if ((seed and 0x10) != 0) sh1 else sh2
        s[1] = s[1] shr sh1; s[2] = s[2] shr sh2; s[3] = s[3] shr sh1; s[4] = s[4] shr sh2
        s[5] = s[5] shr sh1; s[6] = s[6] shr sh2; s[7] = s[7] shr sh1; s[8] = s[8] shr sh2
        s[9] = s[9] shr sh3; s[10] = s[10] shr sh3; s[11] = s[11] shr sh3; s[12] = s[12] shr sh3
        val a = (s[1] * x + s[2] * y + (r ushr 14)) and 63
        val b = (s[4] * x + s[5] * y + (r ushr 10)) and 63
        var c = (s[7] * x + s[8] * y + (r ushr 6)) and 63
        var d = (s[10] * x + s[11] * y + (r ushr 2)) and 63
        if (pc < 4) d = 0
        if (pc < 3) c = 0
        return if (a >= b && a >= c && a >= d) 0 else if (b >= c && b >= d) 1 else if (c >= d) 2 else 3
    }

    // ---- endpoints ----
    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    /** a = offset byte, b = base byte -> t[0] = signed 6-bit offset, t[1] = 7-bit base */
    private fun bts(a: Int, b: Int, t: IntArray) {
        val nb = (b shr 1) or (a and 0x80)
        var na = (a shr 1) and 0x3F
        if ((na and 0x20) != 0) na -= 0x40
        t[0] = na; t[1] = nb
    }

    /** writes 8 ints (e0 rgba, e1 rgba) to dst[o..o+7]; false = unsupported (HDR) */
    private fun endpoints(cem: Int, v: IntArray, p: Int, dst: IntArray, o: Int): Boolean {
        val t = IntArray(2)
        fun put(r0: Int, g0: Int, b0: Int, a0: Int, r1: Int, g1: Int, b1: Int, a1: Int) {
            dst[o] = r0; dst[o + 1] = g0; dst[o + 2] = b0; dst[o + 3] = a0
            dst[o + 4] = r1; dst[o + 5] = g1; dst[o + 6] = b1; dst[o + 7] = a1
        }
        // blue contraction: (r+b)>>1, (g+b)>>1, b
        fun putBc(swap: Boolean, r0: Int, g0: Int, b0: Int, a0: Int, r1: Int, g1: Int, b1: Int, a1: Int) {
            if (!swap) put(r0, g0, b0, a0, r1, g1, b1, a1)
            else put((r1 + b1) shr 1, (g1 + b1) shr 1, b1, a1, (r0 + b0) shr 1, (g0 + b0) shr 1, b0, a0)
        }
        when (cem) {
            0 -> put(v[p], v[p], v[p], 255, v[p + 1], v[p + 1], v[p + 1], 255)
            1 -> {
                val l0 = (v[p] shr 2) or (v[p + 1] and 0xC0)
                val l1 = minOf(255, l0 + (v[p + 1] and 0x3F))
                put(l0, l0, l0, 255, l1, l1, l1, 255)
            }
            4 -> put(v[p], v[p], v[p], v[p + 2], v[p + 1], v[p + 1], v[p + 1], v[p + 3])
            5 -> {
                bts(v[p + 1], v[p], t); val o1 = t[0]; val b0 = t[1]
                bts(v[p + 3], v[p + 2], t); val o3 = t[0]; val b2 = t[1]
                val h = clamp(b0 + o1); val h2 = clamp(b2 + o3)
                put(b0, b0, b0, b2, h, h, h, h2)
            }
            6 -> put((v[p] * v[p + 3]) shr 8, (v[p + 1] * v[p + 3]) shr 8, (v[p + 2] * v[p + 3]) shr 8, 255, v[p], v[p + 1], v[p + 2], 255)
            8 -> {
                val swap = v[p + 1] + v[p + 3] + v[p + 5] < v[p] + v[p + 2] + v[p + 4]
                putBc(swap, v[p], v[p + 2], v[p + 4], 255, v[p + 1], v[p + 3], v[p + 5], 255)
            }
            9 -> {
                bts(v[p + 1], v[p], t); val o1 = t[0]; val b0 = t[1]
                bts(v[p + 3], v[p + 2], t); val o3 = t[0]; val b2 = t[1]
                bts(v[p + 5], v[p + 4], t); val o5 = t[0]; val b4 = t[1]
                val swap = o1 + o3 + o5 < 0
                putBc(swap, b0, b2, b4, 255, clamp(b0 + o1), clamp(b2 + o3), clamp(b4 + o5), 255)
            }
            10 -> put((v[p] * v[p + 3]) shr 8, (v[p + 1] * v[p + 3]) shr 8, (v[p + 2] * v[p + 3]) shr 8, v[p + 4], v[p], v[p + 1], v[p + 2], v[p + 5])
            12 -> {
                val swap = v[p + 1] + v[p + 3] + v[p + 5] < v[p] + v[p + 2] + v[p + 4]
                putBc(swap, v[p], v[p + 2], v[p + 4], v[p + 6], v[p + 1], v[p + 3], v[p + 5], v[p + 7])
            }
            13 -> {
                bts(v[p + 1], v[p], t); val o1 = t[0]; val b0 = t[1]
                bts(v[p + 3], v[p + 2], t); val o3 = t[0]; val b2 = t[1]
                bts(v[p + 5], v[p + 4], t); val o5 = t[0]; val b4 = t[1]
                bts(v[p + 7], v[p + 6], t); val o7 = t[0]; val b6 = t[1]
                val swap = o1 + o3 + o5 < 0
                putBc(swap, b0, b2, b4, b6, clamp(b0 + o1), clamp(b2 + o3), clamp(b4 + o5), clamp(b6 + o7))
            }
            else -> return false
        }
        return true
    }

    // ---- block mode ----
    /** returns [gridW, gridH, dualPlane, weightQuantIndex] or null if reserved/invalid */
    private fun blockMode(bm: Int): IntArray? {
        var base = (bm shr 4) and 1
        var h = (bm shr 9) and 1
        var d = (bm shr 10) and 1
        val a = (bm shr 5) and 3
        val w: Int; val ht: Int
        if ((bm and 3) != 0) {
            base = base or ((bm and 3) shl 1)
            var b = (bm shr 7) and 3
            when ((bm shr 2) and 3) {
                0 -> { w = b + 4; ht = a + 2 }
                1 -> { w = b + 8; ht = a + 2 }
                2 -> { w = a + 2; ht = b + 8 }
                else -> {
                    b = b and 1
                    if ((bm and 0x100) != 0) { w = b + 2; ht = a + 2 } else { w = a + 2; ht = b + 6 }
                }
            }
        } else {
            base = base or (((bm shr 2) and 3) shl 1)
            if (((bm shr 2) and 3) == 0) return null
            val b = (bm shr 9) and 3
            when ((bm shr 7) and 3) {
                0 -> { w = 12; ht = a + 2 }
                1 -> { w = a + 2; ht = 12 }
                2 -> { w = a + 6; ht = b + 6; d = 0; h = 0 }
                else -> {
                    if (a == 0) { w = 6; ht = 10 } else if (a == 1) { w = 10; ht = 6 } else return null
                }
            }
        }
        return intArrayOf(w, ht, d, (base - 2) + 6 * h)
    }

    // ---- one block ----
    private fun decodeBlock(lo: Long, hi: Long, bw: Int, bh: Int, out: IntArray) {
        val n = bw * bh
        val bm = (lo and 0x7FF).toInt()
        if ((bm and 0x1FF) == 0x1FC) {       // void-extent: constant colour
            if (((bm shr 9) and 1) == 1) { java.util.Arrays.fill(out, 0, n, ERR); return }
            val r = ((hi and 0xFFFF) shr 8).toInt(); val g = (((hi ushr 16) and 0xFFFF) shr 8).toInt()
            val b = (((hi ushr 32) and 0xFFFF) shr 8).toInt(); val a = (((hi ushr 48) and 0xFFFF) shr 8).toInt()
            java.util.Arrays.fill(out, 0, n, (a shl 24) or (r shl 16) or (g shl 8) or b); return
        }
        java.util.Arrays.fill(out, 0, n, ERR)
        val m = blockMode(bm) ?: return
        val gw = m[0]; val gh = m[1]; val dual = m[2]; val wq = m[3]
        if (gw > bw || gh > bh) return
        val nw = gw * gh * (1 + dual)
        if (nw > 64) return
        val wbits = iseBits(nw, wq)
        if (wbits < 24 || wbits > 96) return
        val pc = ((bm shr 11) and 3) + 1
        if (dual == 1 && pc == 4) return

        // weights: stored bit-reversed from the top of the block
        val rev = Bits(java.lang.Long.reverse(hi), java.lang.Long.reverse(lo), 0)
        val wd = IntArray(nw); val wm = IntArray(nw)
        iseDecode(rev, nw, wq, wd, wm)
        val weights = IntArray(nw) { unqWeight(wq, wd[it], wm[it]) }

        var below = 128 - wbits
        var ccs = 0
        if (dual == 1) { below -= 2; ccs = Bits(lo, hi, below).get(2) }
        val cems = IntArray(pc)
        val cstart: Int
        if (pc == 1) { cems[0] = Bits(lo, hi, 13).get(4); cstart = 17 }
        else {
            val hiSize = 3 * pc - 4
            below -= hiSize
            val et = Bits(lo, hi, 23).get(6) or (Bits(lo, hi, below).get(hiSize) shl 6)
            var base = et and 3
            if (base == 0) { for (i in 0 until pc) cems[i] = (et shr 2) and 15 }
            else {
                base -= 1
                var bp = 2
                val offs = IntArray(pc)
                for (i in 0 until pc) { offs[i] = (et shr bp) and 1; bp++ }
                for (i in 0 until pc) { cems[i] = ((base + offs[i]) shl 2) or ((et shr bp) and 3); bp += 2 }
            }
            cstart = 29
        }
        var nv = 0
        for (c in cems) nv += 2 * ((c shr 2) + 1)
        if (nv > 18) return
        val avail = below - cstart
        var qi = -1
        for (i in QL.size - 1 downTo 0) { if (iseBits(nv, i) <= avail) { qi = i; break } }
        if (qi < 4) return                    // fewer than 6 levels is not allowed
        val cd = IntArray(nv); val cm = IntArray(nv)
        iseDecode(Bits(lo, hi, cstart), nv, qi, cd, cm)
        val cv = IntArray(nv) { unqColor(qi, cd[it], cm[it]) }
        val ep = IntArray(8 * pc)
        var p = 0
        for (i in 0 until pc) {
            if (!endpoints(cems[i], cv, p, ep, i * 8)) return
            p += 2 * ((cems[i] shr 2) + 1)
        }

        // texel weights (bilinear infill) and colour interpolation
        val ds = if (bw > 1) (1024 + bw / 2) / (bw - 1) else 0
        val dt = if (bh > 1) (1024 + bh / 2) / (bh - 1) else 0
        val small = bw * bh < 31
        val seed = Bits(lo, hi, 13).get(10)
        val planes = 1 + dual
        val w4 = IntArray(4)
        for (t in 0 until bh) for (s in 0 until bw) {
            val gs = ((ds * s) * (gw - 1) + 32) shr 6
            val gt = ((dt * t) * (gh - 1) + 32) shr 6
            val js = gs shr 4; val fs = gs and 15
            val jt = gt shr 4; val ft = gt and 15
            val w11 = (fs * ft + 8) shr 4; val w10 = ft - w11; val w01 = fs - w11; val w00 = 16 - fs - ft + w11
            val x0 = minOf(js, gw - 1); val x1 = minOf(js + 1, gw - 1)
            val y0 = minOf(jt, gh - 1); val y1 = minOf(jt + 1, gh - 1)
            for (pl in 0 until planes) {
                val v = (weights[(x0 + y0 * gw) * planes + pl] * w00 + weights[(x1 + y0 * gw) * planes + pl] * w01 +
                        weights[(x0 + y1 * gw) * planes + pl] * w10 + weights[(x1 + y1 * gw) * planes + pl] * w11 + 8) shr 4
                if (pl == 0) { w4[0] = v; w4[1] = v; w4[2] = v; w4[3] = v } else w4[ccs] = v
            }
            val part = if (pc > 1) partition(seed, s, t, pc, small) else 0
            val o = part * 8
            var px = 0
            for (ch in 0 until 4) {
                val c0 = ep[o + ch] * 257; val c1 = ep[o + 4 + ch] * 257
                val c = (((c0 * (64 - w4[ch]) + c1 * w4[ch] + 32) shr 6) shr 8) and 0xFF
                px = px or (c shl (when (ch) { 0 -> 16; 1 -> 8; 2 -> 0; else -> 24 }))
            }
            out[t * bw + s] = px
        }
    }

    // ---- PNG writer (RGBA8, streamed) ----
    private class PngOut(f: File, val w: Int, val h: Int) {
        private val os = BufferedOutputStream(FileOutputStream(f), 1 shl 16)
        private val def = Deflater(6)
        private val buf = ByteArray(1 shl 16)
        private val crc = CRC32()
        init {
            os.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
            val ihdr = ByteArray(13)
            putInt(ihdr, 0, w); putInt(ihdr, 4, h); ihdr[8] = 8; ihdr[9] = 6   // 8-bit RGBA
            chunk("IHDR", ihdr, 13)
        }
        private fun putInt(a: ByteArray, o: Int, v: Int) { a[o] = (v ushr 24).toByte(); a[o + 1] = (v ushr 16).toByte(); a[o + 2] = (v ushr 8).toByte(); a[o + 3] = v.toByte() }
        private fun chunk(type: String, data: ByteArray, len: Int) {
            val l = ByteArray(4); putInt(l, 0, len); os.write(l)
            val tb = type.toByteArray(Charsets.US_ASCII); os.write(tb)
            os.write(data, 0, len)
            crc.reset(); crc.update(tb); crc.update(data, 0, len)
            val c = ByteArray(4); putInt(c, 0, crc.value.toInt()); os.write(c)
        }
        /** scan = rows * (1 + w*4) bytes, each row starts with filter byte 0 */
        fun rows(scan: ByteArray, len: Int) {
            def.setInput(scan, 0, len)
            while (!def.needsInput()) { val n = def.deflate(buf); if (n > 0) chunk("IDAT", buf, n) }
        }
        fun finish() {
            def.finish()
            while (!def.finished()) { val n = def.deflate(buf); if (n > 0) chunk("IDAT", buf, n) }
            chunk("IEND", ByteArray(0), 0)
            os.close(); def.end()
        }
        fun abort() { try { os.close() } catch (e: Throwable) {}; def.end() }
    }

    // ---- file level ----
    private class Info(val w: Int, val h: Int, val bw: Int, val bh: Int, val offset: Long)

    private fun le32(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)
    private fun le64(b: ByteArray, o: Int): Long = (le32(b, o).toLong() and 0xFFFFFFFFL) or (le32(b, o + 4).toLong() shl 32)

    private val KTX_DIMS = arrayOf(
        intArrayOf(4, 4), intArrayOf(5, 4), intArrayOf(5, 5), intArrayOf(6, 5), intArrayOf(6, 6), intArrayOf(8, 5), intArrayOf(8, 6),
        intArrayOf(8, 8), intArrayOf(10, 5), intArrayOf(10, 6), intArrayOf(10, 8), intArrayOf(10, 10), intArrayOf(12, 10), intArrayOf(12, 12))

    /** null = not an ASTC file */
    private fun parseHeader(f: File): Info? {
        val head = ByteArray(80)
        val got = FileInputStream(f).use { it.read(head) }
        if (got < 16) return null
        // raw .astc: 13 AB A1 5C
        if ((head[0].toInt() and 255) == 0x13 && (head[1].toInt() and 255) == 0xAB && (head[2].toInt() and 255) == 0xA1 && (head[3].toInt() and 255) == 0x5C) {
            val bw = head[4].toInt() and 255; val bh = head[5].toInt() and 255; val bz = head[6].toInt() and 255
            val w = (head[7].toInt() and 255) or ((head[8].toInt() and 255) shl 8) or ((head[9].toInt() and 255) shl 16)
            val h = (head[10].toInt() and 255) or ((head[11].toInt() and 255) shl 8) or ((head[12].toInt() and 255) shl 16)
            if (bz > 1) throw IllegalArgumentException("3D ASTC not supported")
            return Info(w, h, bw, bh, 16)
        }
        // KTX1: AB 4B 54 58 20 31 31 BB
        if (got >= 64 && (head[0].toInt() and 255) == 0xAB && head[1] == 'K'.code.toByte() && head[2] == 'T'.code.toByte() && head[3] == 'X'.code.toByte() && head[5] == '1'.code.toByte() && head[6] == '1'.code.toByte()) {
            val fmt = le32(head, 28)
            val idx = if (fmt in 0x93B0..0x93BD) fmt - 0x93B0 else if (fmt in 0x93D0..0x93DD) fmt - 0x93D0 else return null
            val w = le32(head, 36); val h = le32(head, 40)
            val kv = le32(head, 60)
            return Info(w, h, KTX_DIMS[idx][0], KTX_DIMS[idx][1], 64L + kv + 4)   // +4 = imageSize of mip 0
        }
        return null
    }

    /** Decodes [src] (ASTC/KTX-ASTC) into the PNG file [dst]. Throws on bad data. */
    fun toPng(src: File, dst: File) {
        val info = parseHeader(src) ?: throw IllegalArgumentException("not ASTC")
        val w = info.w; val h = info.h; val bw = info.bw; val bh = info.bh
        if (w < 1 || h < 1 || w > 16384 || h > 16384) throw IllegalArgumentException("bad size ${w}x$h")
        if (bw < 4 || bw > 12 || bh < 4 || bh > 12) throw IllegalArgumentException("bad block ${bw}x$bh")
        val bx = (w + bw - 1) / bw; val by = (h + bh - 1) / bh
        if (src.length() - info.offset < bx.toLong() * by * 16) throw IllegalArgumentException("file too short")
        val rowLen = 1 + w * 4
        val scan = ByteArray(bh * rowLen)
        val rowBuf = ByteArray(bx * 16)
        val blk = IntArray(bw * bh)
        val png = PngOut(dst, w, h)
        try {
            FileInputStream(src).use { ins ->
                var skip = info.offset
                while (skip > 0) { val s = ins.skip(skip); if (s <= 0) throw IllegalArgumentException("seek failed"); skip -= s }
                for (j in 0 until by) {
                    var read = 0
                    while (read < rowBuf.size) { val n = ins.read(rowBuf, read, rowBuf.size - read); if (n < 0) throw IllegalArgumentException("file too short"); read += n }
                    val rows = minOf(bh, h - j * bh)
                    for (t in 0 until rows) scan[t * rowLen] = 0
                    for (i in 0 until bx) {
                        decodeBlock(le64(rowBuf, i * 16), le64(rowBuf, i * 16 + 8), bw, bh, blk)
                        for (t in 0 until rows) {
                            var o = t * rowLen + 1 + i * bw * 4
                            val maxS = minOf(bw, w - i * bw)
                            for (s in 0 until maxS) {
                                val px = blk[t * bw + s]
                                scan[o] = (px shr 16).toByte(); scan[o + 1] = (px shr 8).toByte(); scan[o + 2] = px.toByte(); scan[o + 3] = (px ushr 24).toByte()
                                o += 4
                            }
                        }
                    }
                    png.rows(scan, rows * rowLen)
                }
            }
            png.finish()
        } catch (t: Throwable) { png.abort(); dst.delete(); throw t }
    }

    /**
     * Converts every ASTC / KTX-ASTC texture under [root] to PNG (same name, .png). The original is removed on success.
     * Failures are added to [report] and the original file is kept. Returns how many files were converted.
     */
    fun convertTree(root: File, report: MutableList<String>): Int {
        var done = 0
        val files = root.walkTopDown().filter { it.isFile && it.length() in 17..300_000_000L }.toList()
        for (f in files) {
            var info: Info? = null
            try { info = parseHeader(f) } catch (e: Throwable) { report.add("astc: ${f.name}: ${e.message}") }
            if (info == null || info.bw < 4) continue
            val isPng = f.extension.equals("png", true)
            val target = if (isPng) f else File(f.parentFile, f.nameWithoutExtension + ".png")
            if (!isPng && target.exists()) { report.add("astc: ${f.name} skipped (a PNG with the same name already exists)"); continue }
            val tmp = File(f.parentFile, f.name + ".astc_tmp")
            try {
                toPng(f, tmp)
                f.delete()
                if (!tmp.renameTo(target)) { tmp.copyTo(target, overwrite = true); tmp.delete() }
                done++
            } catch (e: Throwable) {
                tmp.delete()
                report.add("astc: could not convert ${f.name}: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        if (done > 0) report.add("astc: $done texture(s) decoded to PNG")
        return done
    }
}
