package com.portyou.studio.convert

import java.io.File

enum class ModType { FUNKY_MAKER, VSLICE, UNKNOWN }

object ModDetector {
    /** Returns the type and the folder that is the mod's real root (archives often wrap everything in one folder). */
    fun detect(dir: File): Pair<ModType, File> {
        var root = dir
        repeat(3) {
            if (File(root, "data.json").isFile && File(root, "scene.json").isFile && File(root, "sprites").isDirectory)
                return ModType.FUNKY_MAKER to root
            if (File(root, "_polymod_meta.json").isFile) return ModType.VSLICE to root
            val kids = root.listFiles()?.filter { !it.name.startsWith("__MACOSX") } ?: emptyList()
            if (kids.size == 1 && kids[0].isDirectory) root = kids[0] else return@repeat
        }
        // V-Slice mods without a meta file: charts named *-chart.json / *-metadata.json or .hxc scripts
        val any = dir.walkTopDown().take(4000).toList()
        if (any.any { it.name.endsWith("-chart.json") || it.name.endsWith("-metadata.json") || it.extension == "hxc" })
            return ModType.VSLICE to dir
        return ModType.UNKNOWN to dir
    }
}
