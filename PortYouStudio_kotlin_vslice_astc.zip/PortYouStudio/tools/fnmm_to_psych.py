#!/usr/bin/env python3
"""Reference implementation of the FNMM -> Psych Engine (1.0.4 mobile) converter.
The Kotlin app (FunkyMakerConverter.kt) is a line-by-line port of this file.
Usage: fnmm_to_psych.py mod.FNMM out_dir"""
import json, math, os, re, sys, zipfile, io
from PIL import Image

DIRS = ['idle', 'singLEFT', 'singDOWN', 'singUP', 'singRIGHT', 'miss', 'special']
XMLP = ['idle_', 'left_', 'down_', 'up_', 'right_', 'miss_', 'special_']
BASE_FPS = 10.0  # spd (non-fps) is treated as multiplier over this base
report = []

def slug(s):
    s = re.sub(r'[^A-Za-z0-9_-]+', '-', s).strip('-').lower()
    return s if len(re.sub(r'[^a-z0-9]', '', s)) >= 2 else 'fnmm-mod'

def strip_frames(img, num):
    num = max(1, int(float(num)))
    fw = img.width // num
    return [img.crop((i * fw, 0, (i + 1) * fw, img.height)) for i in range(num)]

def build_atlas(frames_by_anim, prefixes):
    cw = max(f.width for fr in frames_by_anim for f in fr)
    ch = max(f.height for fr in frames_by_anim for f in fr)
    total = sum(len(fr) for fr in frames_by_anim)
    cols = max(1, min(total, 4096 // cw))
    rows = math.ceil(total / cols)
    sheet = Image.new('RGBA', (cols * cw, rows * ch), (0, 0, 0, 0))
    xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<TextureAtlas imagePath="%s">']
    n = 0
    for fr, pre in zip(frames_by_anim, prefixes):
        for i, f in enumerate(fr):
            x, y = (n % cols) * cw, (n // cols) * ch
            sheet.paste(f, (x + (cw - f.width) // 2, y + (ch - f.height) // 2))
            xml.append('\t<SubTexture name="%s%04d" x="%d" y="%d" width="%d" height="%d"/>' % (pre, i, x, y, cw, ch))
            n += 1
    xml.append('</TextureAtlas>')
    return sheet, xml, cw, ch

def lua_str(s): return "'" + str(s).replace('\\', '\\\\').replace("'", "\\'") + "'"

def convert(src, out):
    z = zipfile.ZipFile(src)
    rd = lambda n: json.loads(z.read(n))
    data, scene, events = rd('data.json'), rd('scene.json'), rd('events.json')
    name = slug(os.path.splitext(os.path.basename(src))[0])
    song = name
    bpm = float(data.get('bpm', 120))
    beat_ms = 60000.0 / bpm
    sec_ms = beat_ms * 4
    mk = lambda *p: os.makedirs(os.path.join(out, *p), exist_ok=True)
    for d in ['characters', 'data/' + song, 'images/characters', 'images/' + name, 'images/icons',
              'songs/' + song, 'stages', 'weeks', 'scripts', 'custom_events']:
        mk(*d.split('/'))
    P = lambda *p: os.path.join(out, *p)

    # ---------- chart ----------
    # psych_v1 = ABSOLUTE lanes: data 0-3 = player, 4-7 = opponent, whatever mustHitSection says (it only drives the camera).
    # FNMM strumLine 0 = player, 1 = opponent, 2+ = girlfriend (kept on the opponent side with the 'GF Sing' note type,
    # so her arrows never mix with the player's or the opponent's).
    notes, last = [], 0
    for sl, lanes in enumerate(data['strumLines']):
        side = 0 if sl == 0 else 4
        ntype = 'GF Sing' if sl >= 2 else ''
        for lane, lst in enumerate(lanes[:4]):
            for n in lst:
                ms = n['start'] * 1000.0
                ln = n.get('duration', 0) * 1000.0
                if ln < beat_ms / 8: ln = 0
                notes.append((ms, lane + side, ln, ntype))
                last = max(last, ms + ln)
    nsec = int(last // sec_ms) + 2
    secs = [dict(sectionNotes=[], sectionBeats=4, mustHitSection=True, gfSection=False, bpm=bpm, changeBPM=False) for _ in range(nsec)]
    for ms, d, ln, nt in sorted(notes, key=lambda x: (x[0], x[1])):
        secs[int(ms // sec_ms)]['sectionNotes'].append([ms, d, ln, nt])
    objs = scene['objects']
    char_obj = {}  # strumLine -> object idx
    for i, o in enumerate(objs):
        sl = int(o.get('strumLine', -1))
        if sl in (0, 1) and sl not in char_obj: char_obj[sl] = i
    json.dump(dict(song=song, notes=secs, bpm=bpm, needsVoices=False, speed=2.5, offset=0,
                   player1='fnmm-player', player2='fnmm-enemy' if 1 in char_obj else 'bf', gfVersion='gf', stage=name, events=[],
                   format='psych_v1', arrowSkin='', splashSkin='noteSplashes/noteSplashes'),
              open(P('data', song, song + '.json'), 'w'), indent=1)

    # ---------- sprites ----------
    spr = {}
    for n in z.namelist():
        m = re.match(r'sprites/([^/]+)/sprite\.json$', n)
        if m: spr[m.group(1)] = rd(n)
    def strips(sn):
        out_ = []
        for i, a in enumerate(spr[sn]['data']):
            out_.append((a, Image.open(io.BytesIO(z.read('sprites/%s/%d.png' % (sn, i)))).convert('RGBA')))
        return out_
    chars = {}
    for sl, key in ((0, 'fnmm-player'), (1, 'fnmm-enemy')):
        if sl not in char_obj: continue
        o = objs[char_obj[sl]]; sn = o['spr']; sc = float(o['scale']['x'])
        st = strips(sn)
        frames = [strip_frames(img, a['num']) for a, img in st]
        pres = [XMLP[min(i, len(XMLP) - 1)] if i < len(XMLP) else 'extra%d_' % i for i in range(len(frames))]
        sheet, xml, cw, ch = build_atlas(frames, pres)
        sheet.save(P('images', 'characters', key + '.png'))
        open(P('images', 'characters', key + '.xml'), 'w').write('\n'.join(xml).replace('%s', key + '.png'))
        anims = []
        for i, (a, _) in enumerate(st):
            an = DIRS[i] if i < len(DIRS) else 'extra%d' % i
            fps = a['spd'] if a.get('spd_fps') else a['spd'] * BASE_FPS
            anims.append(dict(loop=bool(a.get('loop', True)) if an == 'idle' else False, offsets=[0, 0], anim=an,
                              fps=int(round(fps)), name=pres[i], indices=[]))
            if an == 'miss':
                for d in ('LEFT', 'DOWN', 'UP', 'RIGHT'):
                    anims.append(dict(anims[-1], anim='sing%smiss' % d))
        chars[key] = dict(cw=cw, ch=ch, scale=sc, o=o)
        json.dump(dict(animations=anims, vocals_file='', no_antialiasing=False, image='characters/' + key,
                       position=[0, 0], healthicon=key, flip_x=(sl == 0), healthbar_colors=[252, 252, 4] if sl == 0 else [252, 4, 108],
                       camera_position=[0, 0], sing_duration=4, scale=sc, _editor_isPlayer=(sl == 0)),
                  open(P('characters', key + '.json'), 'w'), indent=1)
    # icons: every type-3 sprite becomes icon-<name>.png (2 frames side by side)
    for sn, sj in spr.items():
        if int(sj['type']) != 3: continue
        fr = [f for _, im in strips(sn) for f in strip_frames(im, 1)][:2]
        while len(fr) < 2: fr.append(fr[0])
        h = max(f.height for f in fr); w = max(f.width for f in fr)
        sh = Image.new('RGBA', (w * 2, h), (0, 0, 0, 0))
        for j, f in enumerate(fr): sh.paste(f, (j * w, 0))
        sh.save(P('images', 'icons', 'icon-fnmm-' + sn + '.png'))
        icons = scene.get('icons', [])
        for i, ic in enumerate(icons[:2]):
            if ic == sn: sh.save(P('images', 'icons', 'icon-' + ('fnmm-player' if i == 0 else 'fnmm-enemy') + '.png'))
    # world objects (everything that is not a player/enemy character)
    OBJ = []
    for i, o in enumerate(objs):
        sn = o['spr']; ch_ = i in char_obj.values()
        if ch_ or sn not in spr: continue
        alist = []
        for k, (a, img) in enumerate(strips(sn)):
            num = max(1, int(float(a['num'])))
            fn = '%s/%s_%d' % (name, sn, k)
            if int(spr[sn]['type']) not in (0, 2): img.save(P('images', name, '%s_%d.png' % (sn, k)))
            fps = a['spd'] if a.get('spd_fps') else a['spd'] * BASE_FPS
            alist.append("{img=%s, fw=%d, fh=%d, frames=%d, fps=%s, loop=%s}" % (lua_str(fn), img.width // num, img.height, num, round(fps, 3), 'true' if a.get('loop', True) else 'false'))
        OBJ.append("\t{idx=%d, spr=%s, cx=%s, cy=%s, scale=%s, visible=%s, fixed=%s, anims={%s}}," % (
            i, lua_str(sn), o['x'], o['y'], o['scale']['x'], 'true' if o.get('visible', True) else 'false',
            'true' if o.get('fixed') else 'false', ', '.join(alist)))
    SPRS = []
    for sn in spr:
        if int(spr[sn]['type']) not in (0, 2): continue   # characters/icons live in their own atlases
        al = []
        for k, (a, img) in enumerate(strips(sn)):
            num = max(1, int(float(a['num'])))
            img.save(P('images', name, '%s_%d.png' % (sn, k)))
            fps = a['spd'] if a.get('spd_fps') else a['spd'] * BASE_FPS
            al.append("{img=%s, fw=%d, fh=%d, frames=%d, fps=%s, loop=%s}" % (lua_str('%s/%s_%d' % (name, sn, k)), img.width // num, img.height, num, round(fps, 3), 'true' if a.get('loop', True) else 'false'))
        SPRS.append("\t[%s] = {%s}," % (lua_str(sn), ', '.join(al)))

    # ---------- stage ----------
    cam = (scene.get('cameras') or [{'x': 1080, 'y': 960, 'scale': 1}])[0]
    def tl(sl):
        c = chars.get({0: 'fnmm-player', 1: 'fnmm-enemy'}[sl]) if sl in char_obj else None
        if not c: return [0, 0]
        return [c['o']['x'] - c['cw'] * c['scale'] / 2, c['o']['y'] - c['ch'] * c['scale'] / 2]
    json.dump(dict(directory='', defaultZoom=round(float(cam.get('scale', 1)) * 0.7, 3), isPixelStage=False,
                   boyfriend=tl(0), girlfriend=[400, 130], opponent=tl(1), hide_girlfriend=True,
                   camera_boyfriend=[0, 0], camera_opponent=[0, 0], camera_girlfriend=[0, 0], camera_speed=100),
              open(P('stages', name + '.json'), 'w'), indent=1)

    # ---------- events ----------
    # Every FNMM action becomes a Psych event  [Type, "k=v;k=v", ""]  (lossless); fnmm_runtime.lua executes them.
    CATALOG = {'ScreenFlash', 'CameraShake', 'CameraSet', 'BarIconChange', 'ObjectSpriteSet', 'ObjectChartChange',
               'ObjectAnimationSet', 'ObjectVisibilitySet', 'ObjectOpacitySet', 'PlayerHealth', 'RunActionPack',
               'GUI', 'ObjectBlendColor', 'CameraZoom', 'ObjectPositionSet'}
    packs = events.get('action_packs', [])
    unknown = set()
    def flat(p, pre=''):
        r = []
        for k, v in p.items():
            if isinstance(v, dict): r += flat(v, pre + k + '.')
            else:
                if isinstance(v, float) and v == int(v): v = int(v)
                if isinstance(v, bool): v = int(v)
                r.append('%s%s=%s' % (pre, k, str(v).replace(';', ',')))
        return r
    def expand(actions, depth=0):
        out_ = []
        for a_ in actions:
            t, p = a_['type'], a_.get('props', {})
            if t == 'RunActionPack':
                i = int(p.get('actionPack', 0))
                if depth < 8 and 0 <= i < len(packs): out_ += expand(packs[i].get('actions', []), depth + 1)
                continue
            if t not in CATALOG: unknown.add(t)
            out_.append([t, ';'.join(flat(p)), ''])
        return out_
    EVN = []
    for ev in events.get('events', []):
        row = expand(ev.get('actions', []))
        if row: EVN.append([ev['time'] * 1000.0, row])
    EVN.sort(key=lambda r: r[0])
    cp = P('data', song, song + '.json')
    cj = json.load(open(cp)); cj['events'] = EVN
    json.dump(cj, open(cp, 'w'), indent=1)   # events live INSIDE the chart; no separate events.json (it would run twice)
    used = {r[0] for e_ in EVN for r in e_[1]}
    for t in sorted(used):
        open(P('custom_events', t + '.txt'), 'w').write('FNMM %s (executed by scripts/fnmm_runtime.lua)' % t)
    if unknown: report.append('Unknown FNMM actions kept as events (manual work needed): ' + ', '.join(sorted(unknown)))
    CAMS = ', '.join('{%s, %s, %s}' % (c['x'], c['y'], c.get('scale', 1)) for c in (scene.get('cameras') or [cam]))

    # ---------- runtime lua ----------
    runtime = open(os.path.join(os.path.dirname(__file__), 'fnmm_runtime.lua')).read()
    runtime = runtime.replace('--[[CAMS]]', CAMS).replace('--[[OBJS]]', '\n'.join(OBJ)).replace('--[[SPRS]]', '\n'.join(SPRS))
    runtime = runtime.replace('--[[CHAROBJ]]', 'local CHAR_OBJ = {[0]=%s, [1]=%s}' % (char_obj.get(0, -1), char_obj.get(1, -1)))
    open(P('scripts', 'fnmm_runtime.lua'), 'w').write(runtime)

    # ---------- week / pack / audio ----------
    json.dump(dict(songs=[[song, 'fnmm-enemy', [252, 4, 108]]], weekCharacters=['', 'bf', 'gf'], weekBackground='', weekBefore='tutorial',
                   storyName=name, weekName=name, startUnlocked=True, hideStoryMode=True, hideFreeplay=False, difficulties='Normal'),
              open(P('weeks', name + '.json'), 'w'), indent=1)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from portyou import credits
    credits.write(out, name, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app/src/main/assets/converter/pack.png'), (252, 4, 108))
    for n in z.namelist():
        if n.lower().endswith(('.ogg', '.mp3', '.wav')):
            nm = 'Inst.ogg' if n.startswith('music') else os.path.basename(n)
            open(P('songs', song, nm), 'wb').write(z.read(n))
    return report

if __name__ == '__main__':
    for r in convert(sys.argv[1], sys.argv[2]): print('REPORT:', r)
