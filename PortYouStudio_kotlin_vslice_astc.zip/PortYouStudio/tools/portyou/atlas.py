"""PortYou main atlas engine (one tool for both converters).

  * SpriteMapReader  - reads Adobe Animate texture atlases (Animation.json + spritemap*.json/png),
                       rebuilds the symbol timelines and renders every frame of a label.
  * pack_sparrow     - packs rendered/cut frames into a classic Sparrow sheet (png + xml).
  * cut_strip        - Funky Maker style horizontal strips -> frames.
  * is_placeholder   - detects stripped (1x1 / empty) atlas images.
"""
import json, math, os, glob
import xml.etree.ElementTree as ET
from PIL import Image

MAX_SHEET = 4096


def load_json(path):
    with open(path, 'r', encoding='utf-8-sig') as f:
        return json.load(f)


def is_placeholder(png_path):
    try:
        im = Image.open(png_path).convert('RGBA')
    except Exception:
        return True
    if im.width <= 4 and im.height <= 4:
        return True
    return im.getchannel('A').getbbox() is None


# ----------------------------------------------------------------------------- matrices
def mx_of(el):
    """Animate matrix of an element -> (a, b, c, d, tx, ty)."""
    if 'MX' in el and el['MX']:
        return tuple(el['MX'])
    m = el.get('M3D')
    if m and len(m) >= 14:
        return (m[0], m[1], m[4], m[5], m[12], m[13])
    return (1, 0, 0, 1, 0, 0)


def mx_mul(p, c):
    """parent o child."""
    a, b, cc, d, tx, ty = p
    a2, b2, c2, d2, tx2, ty2 = c
    return (a * a2 + cc * b2, b * a2 + d * b2,
            a * c2 + cc * d2, b * c2 + d * d2,
            a * tx2 + cc * ty2 + tx, b * tx2 + d * ty2 + ty)


# ----------------------------------------------------------------------------- spritemap reader
class SpriteMapReader:
    def __init__(self, folder):
        self.folder = folder
        self.anim = load_json(os.path.join(folder, 'Animation.json'))
        self.symbols = {}
        for s in self.anim.get('SD', {}).get('S', []):
            self.symbols[s['SN']] = s['TL']
        self.main = self.anim['AN']['TL']
        self.sprites = {}
        self.placeholder = False
        for jf in sorted(glob.glob(os.path.join(folder, 'spritemap*.json'))):
            meta = load_json(jf)
            png = os.path.join(folder, meta.get('meta', {}).get('image', os.path.basename(jf)[:-5] + '.png'))
            if not os.path.isfile(png):
                png = jf[:-5] + '.png'
            if is_placeholder(png):
                self.placeholder = True
                continue
            sheet = Image.open(png).convert('RGBA')
            for sp in meta['ATLAS']['SPRITES']:
                s = sp['SPRITE']
                box = (s['x'], s['y'], s['x'] + (s['h'] if s.get('rotated') else s['w']),
                       s['y'] + (s['w'] if s.get('rotated') else s['h']))
                im = sheet.crop(box)
                if s.get('rotated'):
                    im = im.transpose(Image.ROTATE_90)
                self.sprites[s['name']] = im

    # ---- labels of the main timeline (layer holding frame names)
    def labels(self):
        out = {}
        for layer in self.main['L']:
            for fr in layer['FR']:
                if 'N' in fr:
                    out[fr['N']] = (fr['I'], fr['DU'])
        return out

    @staticmethod
    def _norm(n):
        import re
        return re.sub(r'[^a-z0-9]+', '', re.sub(r'\d+$', '', n.lower()))

    def find_label(self, wanted, hint=None):
        """Smart label lookup: exact -> prefix -> same words -> fuzzy (difflib) -> optional AI hint.
        V-Slice animation 'prefix' values rarely match Animate frame labels 1:1 (case, '0000' suffix, 'idle' vs 'Idle_Dance')."""
        import difflib
        labs = self.labels()
        w = wanted.lower()
        for k, v in labs.items():
            if k.lower() == w:
                return k, v
        for k, v in labs.items():
            if k.lower().startswith(w):
                return k, v
        nw = self._norm(wanted)
        for k, v in labs.items():
            if self._norm(k) == nw:
                return k, v
        for k, v in labs.items():
            if nw and (nw in self._norm(k) or self._norm(k) in nw) and len(self._norm(k)) >= 3:
                return k, v
        names = {self._norm(k): k for k in labs}
        m = difflib.get_close_matches(nw, list(names), n=1, cutoff=0.6)
        if m:
            k = names[m[0]]
            return k, labs[k]
        if hint:                         # optional local-AI suggestion (see portyou/ai.py)
            k = hint(wanted, list(labs))
            if k in labs:
                return k, labs[k]
        return None

    def _length(self, tl):
        n = 0
        for layer in tl['L']:
            for fr in layer['FR']:
                n = max(n, fr['I'] + fr['DU'])
        return max(n, 1)

    def _collect(self, tl, t, mat, out, depth=0):
        if depth > 24:
            return
        for layer in reversed(tl['L']):  # first layer is the top one
            for fr in layer['FR']:
                if fr['I'] <= t < fr['I'] + fr['DU']:
                    for el in fr.get('E', []):
                        if 'ASI' in el:
                            a = el['ASI']
                            out.append((a['N'] if 'N' in a else str(a.get('Index', 0)), mx_mul(mat, mx_of(a))))
                        elif 'SI' in el:
                            si = el['SI']
                            sym = self.symbols.get(si['SN'])
                            if sym is None:
                                continue
                            ln = self._length(sym)
                            off = t - fr['I']
                            mode = si.get('LP', 'LP')
                            ff = si.get('FF', 0)
                            if mode == 'SF':
                                ct = ff
                            elif mode == 'PO':
                                ct = min(ff + off, ln - 1)
                            else:
                                ct = (ff + off) % ln
                            self._collect(sym, ct, mx_mul(mat, mx_of(si)), out, depth + 1)

    def frame_quads(self, t):
        out = []
        self._collect(self.main, t, (1, 0, 0, 1, 0, 0), out)
        return out

    @staticmethod
    def _bbox(quads, sprites):
        xs, ys = [], []
        for name, m in quads:
            im = sprites.get(name)
            if im is None:
                continue
            a, b, c, d, tx, ty = m
            for px, py in ((0, 0), (im.width, 0), (0, im.height), (im.width, im.height)):
                xs.append(a * px + c * py + tx)
                ys.append(b * px + d * py + ty)
        if not xs:
            return None
        return min(xs), min(ys), max(xs), max(ys)

    def render_label(self, label_name, scale=1.0, max_px=2048, hint=None):
        """Renders every frame of a label -> list of (RGBA image, origin_x, origin_y) with a SHARED origin."""
        lab = self.find_label(label_name, hint)
        if lab is None:
            return None
        _, (start, dur) = lab
        per = [self.frame_quads(start + i) for i in range(dur)]
        boxes = [b for b in (self._bbox(q, self.sprites) for q in per) if b]
        if not boxes:
            return None
        x0 = math.floor(min(b[0] for b in boxes)); y0 = math.floor(min(b[1] for b in boxes))
        x1 = math.ceil(max(b[2] for b in boxes)); y1 = math.ceil(max(b[3] for b in boxes))
        w, h = max(1, x1 - x0), max(1, y1 - y0)
        s = min(scale, max_px / max(w, h))
        cw, ch = max(1, int(round(w * s))), max(1, int(round(h * s)))
        frames = []
        for quads in per:
            canvas = Image.new('RGBA', (cw, ch), (0, 0, 0, 0))
            for name, m in quads:
                im = self.sprites.get(name)
                if im is None:
                    continue
                a, b, c, d, tx, ty = m
                a, b, c, d, tx, ty = a * s, b * s, c * s, d * s, (tx - x0) * s, (ty - y0) * s
                det = a * d - b * c
                if abs(det) < 1e-9:
                    continue
                ia, ib, ic, idd = d / det, -b / det, -c / det, a / det
                ix = -(ia * tx + ic * ty)
                iy = -(ib * tx + idd * ty)
                layer = im.transform((cw, ch), Image.AFFINE, (ia, ic, ix, ib, idd, iy), resample=Image.BICUBIC)
                canvas.alpha_composite(layer)
            frames.append(canvas)
        return frames, (x0, y0), s


# ----------------------------------------------------------------------------- sparrow
def trim(img):
    bb = img.getchannel('A').getbbox()
    if bb is None:
        return img.crop((0, 0, 1, 1)), 0, 0
    return img.crop(bb), bb[0], bb[1]


def pack_sparrow(groups, out_png, out_xml, image_name=None, pad=2):
    """groups: list of (prefix, [RGBA frames]) -> sparrow sheet. Frame names are prefix + %04d.
    Frames of one prefix keep their canvas size in frameWidth/frameHeight so animations never jitter."""
    items = []
    for prefix, frames in groups:
        for i, f in enumerate(frames):
            t, ox, oy = trim(f)
            items.append(dict(name='%s%04d' % (prefix, i), img=t, fx=-ox, fy=-oy, fw=f.width, fh=f.height))
    order = sorted(range(len(items)), key=lambda k: -items[k]['img'].height)
    x = y = rowh = 0
    maxw = 0
    pos = {}
    width = MAX_SHEET
    tot = sum((it['img'].width + pad) * (it['img'].height + pad) for it in items)
    width = min(MAX_SHEET, max(256, int(math.sqrt(tot) * 1.15)))
    widest = max((it['img'].width + pad for it in items), default=1)
    width = max(width, widest)
    for k in order:
        it = items[k]
        w, h = it['img'].width + pad, it['img'].height + pad
        if x + w > width:
            x = 0; y += rowh; rowh = 0
        pos[k] = (x, y); x += w; rowh = max(rowh, h); maxw = max(maxw, x)
    H = y + rowh
    sheet = Image.new('RGBA', (max(1, maxw), max(1, H)), (0, 0, 0, 0))
    root = ET.Element('TextureAtlas', imagePath=image_name or os.path.basename(out_png))
    for k, it in enumerate(items):
        px, py = pos[k]
        sheet.paste(it['img'], (px, py))
        ET.SubElement(root, 'SubTexture', name=it['name'], x=str(px), y=str(py), width=str(it['img'].width),
                      height=str(it['img'].height), frameX=str(it['fx']), frameY=str(it['fy']),
                      frameWidth=str(it['fw']), frameHeight=str(it['fh']))
    os.makedirs(os.path.dirname(out_png), exist_ok=True)
    sheet.save(out_png, optimize=True)
    ET.indent(root)
    ET.ElementTree(root).write(out_xml, encoding='utf-8', xml_declaration=True)
    return sheet.size


def cut_strip(img, n):
    n = max(1, int(n))
    fw = img.width // n
    return [img.crop((i * fw, 0, (i + 1) * fw, img.height)) for i in range(n)]


def sparrow_first_frame_size(xml_path, prefix):
    """(frameWidth, frameHeight) of the first frame whose name starts with prefix."""
    try:
        root = ET.parse(xml_path).getroot()
    except Exception:
        return None
    for st in root.iter('SubTexture'):
        if st.get('name', '').lower().startswith(prefix.lower()):
            w = int(float(st.get('frameWidth') or st.get('width')))
            h = int(float(st.get('frameHeight') or st.get('height')))
            return w, h
    return None
