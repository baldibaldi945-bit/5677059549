#!/usr/bin/env python3
"""Copies the original UI art into app/src/main/assets/ui with ASCII names, crops layers to their
alpha bounding box (saves RAM/APK size) and writes layout.json (x,y,w,h in the 1080x1920 design space)."""
import glob, json, os, shutil, sys
from PIL import Image
SRC = sys.argv[1]; DST = sys.argv[2]
os.makedirs(DST, exist_ok=True)
def one(pattern):
    r = sorted(glob.glob(os.path.join(SRC, pattern)))
    assert r, pattern
    return r[0]
FULL = {  # full-bleed layers are kept uncropped
 'main1': 'واجهة التطببق.zip_x/1.png', 'main2': 'واجهة التطببق.zip_x/2.png',
 'main3': 'واجهة التطببق.zip_x/3.png', 'main4': 'واجهة التطببق.zip_x/4.png',
 'set_bg': 'واجهة الاعدادات العامة.zip_x/bg*.png', 'black': 'شاشة الانتضار و شاشة النجاح.zip_x/شاشة سودة*.png'}
CROP = {
 'set_sound_panel': 'واجهة الاعدادات العامة.zip_x/3.png', 'btn_lang': 'واجهة الاعدادات العامة.zip_x/زر اللغات.png',
 'btn_sound': 'واجهة الاعدادات العامة.zip_x/زر ايقاف*.png', 'btn_insta': 'واجهة الاعدادات العامة.zip_x/زر رابط انستا*.png',
 'btn_youtube': 'واجهة الاعدادات العامة.zip_x/زر رابط يوتيوب*.png', 'tick_lang': 'واجهة الاعدادات العامة.zip_x/زر صح يوضع جنب*',
 'tick_sound': 'واجهة الاعدادات العامة.zip_x/زر صح يوضع على*', 'btn_desc': 'واجهة الاعدادات العامة.zip_x/زر وصف*.png',
 'akram': 'واجهة الاعدادات العامة.zip_x/شخصية اكرم.png', 'lang_panel': 'واجهة الاعدادات العامة.zip_x/صور اللغات.png',
 'bubble': 'واجهة الاعدادات العامة.zip_x/فقاعة*', 'desc_ar': 'واجهة الاعدادات العامة.zip_x/وصف.png',
 'ok_btn': 'شاشة الانتضار و شاشة النجاح.zip_x/اك.png', 'ok_tick': 'شاشة الانتضار و شاشة النجاح.zip_x/صح.png',
 'loading_en': 'شاشة الانتضار و شاشة النجاح.zip_x/لوادنج انغليزي.png', 'loading_ar': 'شاشة الانتضار و شاشة النجاح.zip_x/لوادنج عربي*',
 'fail_ok': 'شاشة فشل النقل.zip_x/زر اك.png', 'fail_text_ar': 'شاشة فشل النقل.zip_x/نص*', 'fail_icon': 'شاشة فشل النقل.zip_x/وتفاك.png'}
layout = {}
for k, p in FULL.items():
    Image.open(one(p)).convert('RGBA').save(os.path.join(DST, k + '.png'), optimize=True); layout[k] = [0, 0, 1080, 1920]
for k, p in CROP.items():
    im = Image.open(one(p)).convert('RGBA'); bb = im.getchannel('A').getbbox()
    im.crop(bb).save(os.path.join(DST, k + '.png'), optimize=True); layout[k] = [bb[0], bb[1], bb[2] - bb[0], bb[3] - bb[1]]
json.dump(layout, open(os.path.join(DST, 'layout.json'), 'w'), indent=1)
AUD = {'bgm.ogg': 'الاغنية*.ogg', 'sfx_click.ogg': 'صوت اللمسات.ogg', 'sfx_success.ogg': '3.ogg', 'sfx_fail.ogg': 'عنمدة*.ogg',
       'intro.mp4': 'intro apk.mp4', 'mod_template.zip': 'حاويات مودات سايك انجن .zip'}
adst = os.path.join(DST, '..', 'raw_assets'); os.makedirs(DST, exist_ok=True)
for k, p in AUD.items(): shutil.copy(one(p), os.path.join(DST, k))
# launcher icons
ic = Image.open(one('صورة تطبيق.png')).convert('RGBA')
res = os.path.join(DST, '..', '..', 'res')
for d, s in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    os.makedirs(os.path.join(res, 'mipmap-' + d), exist_ok=True)
    c = Image.new('RGBA', (s, s), (0, 0, 0, 0)); t = ic.copy(); t.thumbnail((s, s), Image.LANCZOS)
    c.paste(t, ((s - t.width) // 2, (s - t.height) // 2)); c.save(os.path.join(res, 'mipmap-' + d, 'ic_launcher.png'))
print('layers:', len(layout))
