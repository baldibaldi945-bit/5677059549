#!/usr/bin/env python3
import sys
from portyou.vslice import main
sys.exit(main(sys.argv))
